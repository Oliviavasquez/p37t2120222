package mx.edu.tesoem.itics.p37t2120222;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView tv1;
    EditText et1, et2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1=(EditText)findViewById(R.id.editTextNumberDecimal);
        et2=(EditText) findViewById(R.id.editTextNumberDecimal2);
        tv1=(TextView) findViewById(R.id.editTextTextPersonName);

    }

    public void Sumar (View view){

        et1.getText().toString();
            String n1=et1.getText().toString();
            String n2=et2.getText().toString();
            float num1=Float.parseFloat(n1);
        float num2=Float.parseFloat(n2);

        float sum=num1+num2;
        String res=String.valueOf(sum);
        tv1.setText(res);

    }

        public void Restar (View view){

            et1.getText().toString();
            String n1=et1.getText().toString();
            String n2=et2.getText().toString();
            float num1=Float.parseFloat(n1);
            float num2=Float.parseFloat(n2);

            float rest=num1-num2;
            String res=String.valueOf(rest);
            tv1.setText(res);



        }

        public void Multiplicar (View view){

            et1.getText().toString();
            String n1=et1.getText().toString();
            String n2=et2.getText().toString();
            float num1=Float.parseFloat(n1);
            float num2=Float.parseFloat(n2);

            float mul=num1*num2;
            String res=String.valueOf(mul);
            tv1.setText(res);
        }

        public void Dividir (View view){

            et1.getText().toString();
            String n1=et1.getText().toString();
            String n2=et2.getText().toString();
            float num1=Float.parseFloat(n1);
            float num2=Float.parseFloat(n2);

            float div=num1/num2;
            String res=String.valueOf(div);
            tv1.setText(res);

        }

}